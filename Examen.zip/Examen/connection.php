<?php
$host = "localhost";
$user = "root"; 
$password = ""; 
$dbname = "db_auriculares";

$conn = new mysqli($host, $user, $password, $dbname);

?>