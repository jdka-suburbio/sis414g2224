<?php
include 'connection.php';

function getAllAuriculares($conn) {
    $sql = "SELECT * FROM auriculares";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}


if (isset($_POST['add'])) {
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $tipo = $_POST['tipo'];
    $duracion_bateria = $_POST['duracion_bateria'];

    $sql = "INSERT INTO auriculares (marca, modelo, tipo, duracion_bateria) VALUES ('$marca', '$modelo', '$tipo', $duracion_bateria)";
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


if (isset($_GET['delete'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM auriculares WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error al eliminar: " . $conn->error;
    }
}
?>