<?php
include 'connection.php';
include 'crud.php';

$auriculares = getAllAuriculares($conn);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auriculares</title>
</head>
<body>
<h1>Lista de Auriculares</h1>
    <table border="0">
        <tr>
            <th>Marca</th>
            <th>Modelo</th>
            <th>Tipo</th>
            <th>Duración de Batería (horas)</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($auriculares as $auricular) : ?>
        <tr>
            <td><?= $auricular['marca']; ?></td>
            <td><?= $auricular['modelo']; ?></td>
            <td><?= $auricular['tipo']; ?></td>
            <td><?= $auricular['duracion_bateria']; ?></td>
            <td>
                <a href="edit.php?id=<?= $auricular['id']; ?>">Editar</a> | 
                <a href="delete.php?id=<?= $auricular['id']; ?>">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h2>Agregar Auricular</h2>
    <form action="crud.php" method="POST">
        <label>Marca: </label><input type="text" name="marca" required><br>
        <label>Modelo: </label><input type="text" name="modelo" required><br>
        <label>Tipo: </label><input type="text" name="tipo" required><br>
        <label>Duración de Batería : </label><input type="number" name="duracion_bateria" required><br>
        <input type="submit" name="add" value="Agregar">
    </form>
</body>
</html>