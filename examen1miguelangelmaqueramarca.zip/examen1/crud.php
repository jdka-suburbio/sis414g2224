<?php
require_once("./connection.php");

function getData($table)
{
    global $conn;
    $query = "SELECT * FROM $table";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        return null;
    }

    $arr = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $arr;
}

function setData($table, $data)
{
    global $conn;   
    $fields = implode(",", array_keys($data));
    $values = '"' . implode('","', array_values($data)) . '"';

    $query = "INSERT INTO $table ($fields) VALUES ($values);";
    
    if (mysqli_query($conn, $query) === false) {
        return false;
    }
    return true;
}

function updateData($table, $id, $data)
{
    global $conn;   
    $set = [];
    foreach ($data as $key => $value) {
        $set[] = "$key=\"$value\"";
    }
    $setString = implode(", ", $set);
    $query = "UPDATE $table SET $setString WHERE id = $id";

    if (mysqli_query($conn, $query) === false) {
        return false;
    }
    return true;
}

function deleteData($table, $id)
{
    global $conn;   
    $query = "DELETE FROM $table WHERE id = $id";

    if (mysqli_query($conn, $query) === false) {
        return false;
    }
    return true;
}
?>

