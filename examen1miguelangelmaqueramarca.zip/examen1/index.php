<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php'); 
    exit;
}
require_once("./crud.php");

$bicicletas = getData('bicicletas');
echo json_encode($bicicletas);

$data = ["id" => 77, "marca" => "china", "modelo" => "china", "tipo" => "todo terreno"];
$response = setData('bicicletas', $data);
echo json_encode(["status" => $response ? 201 : 403]);

$updateData = ["modelo" => "Marlin 7"]; 
$response = updateData('bicicletas', 7, $updateData); 
echo json_encode(["status" => $response ? 200 : 403]);

$response = deleteData('bicicletas', 11);
echo json_encode(["status" => $response ? 200 : 403]); 
?>

